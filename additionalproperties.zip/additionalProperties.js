Hooks.on('ready', () => {
CONFIG.DRAGONBANE.weaponProperties['armorpuncturing'] = 'Armor Puncturing';
CONFIG.DRAGONBANE.weaponProperties['executioner'] = 'Executioner';
CONFIG.DRAGONBANE.weaponProperties['flexible'] = 'Flexible';
CONFIG.DRAGONBANE.weaponProperties['slicer'] = 'Slicer';
CONFIG.DRAGONBANE.weaponProperties['versatile'] = 'Versatile';
});